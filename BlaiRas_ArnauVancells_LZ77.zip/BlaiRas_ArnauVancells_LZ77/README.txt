La carpeta jar cont� el fitxer .jar corresponent al projecte.
La carpeta LzDecoder cont� el projecte de NetBeans.
El fitxer "BlaiRas_ArnauVancells_LZ77_memoria.docx" cont� explicacions de l'exercici.

Per a executar-lo nom�s fa falta executar: "java -jar jar/LzDecoder.jar"

Es poden afegir par�metres d'execuci�, per a m�s informaci� llegir "BlaiRas_ArnauVancells_LZ77_memoria.docx"

