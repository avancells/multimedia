La carpeta jar cont� el fitxer .jar corresponent al projecte.
La carpeta LzDecoder cont� el projecte de NetBeans.
El fitxer "BlaiRas_ArnauVancells_LZ77-text_memoria.docx" cont� explicacions de l'exercici. Tamb� hi ha versi� PDF.
El fitxer "log.xlsx" cont� les taules resultants dels nostres tests.

Per a executar-lo nom�s fa falta executar: "java -jar jar/LzDecoder.jar"

Per a executar-lo per a testejar el temps: "java -jar jar/LzDecoder.jar -i "quijote_short.txt" -mode 3 -mDes 8 -mEnt 4"


