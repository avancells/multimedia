Per a executar el programa tant sols cal utilitzar la comanda: java -jar dist/ProjectePractiques.jar -i "input path"
Hi ha par�metres els quals s�n obligat�ris, com �s el fitxer d'entrada. 
La resta de par�metres tenen valors definits per defecte, es recomana veure les commandes a JCommander fent: java -jar dist/ProjectePractiques.jar -help 1

Seguidament hi ha exemples d'execuci� diferents:
# Exemple execuci� mode batch 
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 1 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 9 --gop 4

# Codificaci�/Decodificaci� mals par�metres
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 7 --gop 10

# Codificaci�/Decodificaci� millors par�metres
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 9 --gop 4

# Codificaci�/Decodificaci� millors par�metres + smooth
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 9 --gop 4 --decoAvg 1

# Codificaci�
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 1 --decode 0 --tileSize 8 --threshold 25 --seekRange 1 --gop 4

# Decodificaci� 
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 0 --decode 1 --tileSize 8 --threshold 25 --seekRange 1 --gop 4

# Exemple velocitat seekRange rapid
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 1 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 2 --gop 4

# Exemple velocitat seekRange lent
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 1 --encode 1 --decode 1 --tileSize 8 --threshold 25 --seekRange 12 --gop 4

# Exemple compressi� 16 pixels
java -jar dist/ProjectePractiques.jar -i zips/Cubo.zip --batch 0 --encode 1 --decode 1 --tileSize 16 --threshold 25 --seekRange 9 --gop 4
